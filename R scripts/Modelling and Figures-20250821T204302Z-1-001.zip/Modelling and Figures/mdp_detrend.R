library(reshape2)
library(ggplot2)
library(tidyverse)
library(plotrix)
library(Kendall)
library(broom)

lakes<- c("Superior","Ontario","Michigan","Huron","Erie")
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/acess")
mdp_ac_f<- read.csv("MDP_s6_8.csv",header = FALSE)
mdp_ac_avg_f<- data.frame(apply(mdp_ac_f[,1:5],1,mean))
colnames(mdp_ac_avg_f)<- c("MDP")

setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Superior/Summer")
mdp_sup<- read.csv("MDP_s6_8.csv")

setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Ontario/Summer")
mdp_ont<- read.csv("MDP_s6_8.csv")

setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Michigan/Summer")
mdp_michigan<- read.csv("MDP_s6_8.csv")

setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Huron/Summer")
mdp_huron<- read.csv("MDP_s6_8.csv")
setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Erie/Summer")
mdp_erie<- read.csv("MDP_s6_8.csv")

mdp_ac_h<- data.frame(mdp_sup['access'],mdp_ont['access'],mdp_michigan['access'],mdp_huron['access'],mdp_erie['access'])
colnames(mdp_ac_h)<- c("Superior","Ontario","Michigan","Huron","Erie")
mdp_ac_avg_h<- data.frame(apply(mdp_ac_h[,1:5],1,mean))
colnames(mdp_ac_avg_h)<- c("MDP")
year<- seq(1979,2100,1)
mdp_ac<- rbind(mdp_ac_avg_h,mdp_ac_avg_f)
mdp_ac$year<- year
mdp_ac$model<- rep("ACCESS",122)
hist<- data.frame(rep("Historical",36))
fut<- data.frame(rep("SSP5-8.5",86))
colnames(hist)<- colnames(fut)<- c("Type")
Timeline<- rbind(hist,fut)
mdp_ac$timeline<- Timeline$Type

setwd("G:/LCS-Filer/ekcarter_r/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/acess")
mdp_ac_ssp370<- read.csv("MDP_s6_8.csv",header = TRUE)
colnames(mdp_ac_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
mdp_ac_avg_ssp370<- data.frame(apply(mdp_ac_ssp370[,1:5],1,mean))
colnames(mdp_ac_avg_ssp370)<- c("MDP")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
mdp_ac_avg_ssp370$year<- year_370
mdp_ac_avg_ssp370$timeline<- fut_370
mdp_ac_avg_ssp370$model<- rep("ACCESS",86)
mdp_ac<- rbind(mdp_ac,mdp_ac_avg_ssp370)

trend_ac<- data.frame(rep(mean(mdp_ac_avg_h$MDP),2))
colnames(trend_ac)<- c("Intercept")
trend_ac$Model<- rep("ACCESS",2)
trend_ac$timeline<- c("SSP3-7.0","SSP5-8.5")
f_yr<- seq(1,86,1)

norm_ac_ssp370<- mdp_ac_avg_ssp370$MDP - mean(mdp_ac_avg_h$MDP)
norm_ac_ssp585<- mdp_ac_avg_f$MDP - mean(mdp_ac_avg_h$MDP)
lm_370<- lm(norm_ac_ssp370 ~ f_yr-1)
lm_585<- lm(norm_ac_ssp585~f_yr-1)
trend_ac$slope<- c(lm_370$coefficients,lm_585$coefficients)
#trend_ac$p.value<- c(summary(lm_370)$coefficients[,4],summary(lm_585)$coefficients[,4])
#2
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/mpi")
mdp_mpi_f<- read.csv("MDP_s6_8.csv",header = TRUE)
colnames(mdp_mpi_f)<- c("Superior","Ontario","Michigan","Huron","Erie")
mdp_mpi_avg_f<- data.frame(apply(mdp_mpi_f[,1:5],1,mean))
colnames(mdp_mpi_avg_f)<- c("MDP")
mdp_mpi_h<- data.frame(mdp_sup['mpi'],mdp_ont['mpi'],mdp_michigan['mpi'],mdp_huron['mpi'],mdp_erie['mpi'])
mdp_mpi_avg_h<- data.frame(apply(mdp_mpi_h[,1:5],1,mean))
colnames(mdp_mpi_avg_h)<- c("MDP")
mdp_mpi<- rbind(mdp_mpi_avg_h,mdp_mpi_avg_f)
year<- seq(1979,2100,1)
mdp_mpi$year<- year
mdp_mpi$model<- rep("MPI",122)
mdp_mpi$timeline<- Timeline$Type

setwd("G:/LCS-Filer/ekcarter_r/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/mpi")
mdp_mpi_ssp370<- read.csv("MDP_s6_8.csv",header = FALSE)
colnames(mdp_mpi_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
mdp_mpi_avg_ssp370<- data.frame(apply(mdp_mpi_ssp370[,1:5],1,mean))
colnames(mdp_mpi_avg_ssp370)<- c("MDP")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
mdp_mpi_avg_ssp370$year<- year_370
mdp_mpi_avg_ssp370$timeline<- fut_370
mdp_mpi_avg_ssp370$model<- rep("MPI",86)
mdp_mpi<- rbind(mdp_mpi,mdp_mpi_avg_ssp370)

trend_mpi<- data.frame(rep(mean(mdp_mpi_avg_h$MDP),2))
colnames(trend_mpi)<- c("Intercept")
trend_mpi$Model<- rep("MPI",2)
trend_mpi$timeline<- c("SSP3-7.0","SSP5-8.5")

norm_mpi_ssp370<- mdp_mpi_avg_ssp370$MDP - mean(mdp_mpi_avg_h$MDP)
norm_mpi_ssp585<- mdp_mpi_avg_f$MDP - mean(mdp_mpi_avg_h$MDP)
lm_370_mpi<- lm(norm_mpi_ssp370~f_yr-1)
lm_585_mpi<- lm(norm_mpi_ssp585~f_yr-1)
trend_mpi$slope<- c(lm_370_mpi$coefficients,lm_585_mpi$coefficients)
#trend_mpi$p.value<- c(summary(lm_370_mpi)$coefficients[,4],summary(lm_585_mpi)$coefficients[,4])
#3
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/mri")
mdp_mri_f<- read.csv("MDP_s6_8.csv",header = FALSE)
colnames(mdp_mri_f)<- c("Superior","Ontario","Michigan","Huron","Erie")
mdp_mri_avg_f<- data.frame(apply(mdp_mri_f[,1:5],1,mean))
colnames(mdp_mri_avg_f)<- c("MDP")
mdp_mri_h<- data.frame(mdp_sup['mri'],mdp_ont['mri'],mdp_michigan['mri'],mdp_huron['mri'],mdp_erie['mri'])
mdp_mri_avg_h<- data.frame(apply(mdp_mri_h[,1:5],1,mean))
colnames(mdp_mri_avg_h)<- c("MDP")
year<- seq(1979,2100,1)
mdp_mri<- rbind(mdp_mri_avg_h,mdp_mri_avg_f)
mdp_mri$year<- year
mdp_mri$model<- rep("MRI",122)
mdp_mri$timeline<- Timeline$Type

setwd("G:/LCS-Filer/ekcarter_r/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/mri")
mdp_mri_ssp370<- read.csv("MDP_s6_8.csv",header = FALSE)
colnames(mdp_mri_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
mdp_mri_avg_ssp370<- data.frame(apply(mdp_mri_ssp370[,1:5],1,mean))
colnames(mdp_mri_avg_ssp370)<- c("MDP")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
mdp_mri_avg_ssp370$year<- year_370
mdp_mri_avg_ssp370$timeline<- fut_370
mdp_mri_avg_ssp370$model<- rep("MRI",86)
mdp_mri<- rbind(mdp_mri,mdp_mri_avg_ssp370)

trend_mri<- data.frame(rep(mean(mdp_mri_avg_h$MDP),2))
colnames(trend_mri)<-c("Intercept")
trend_mri$Model<- rep("MRI",2)
trend_mri$timeline<- c("SSP3-7.0","SSP5-8.5")


norm_mri_ssp370<- mdp_mri_avg_ssp370$MDP - mean(mdp_mri_avg_h$MDP)
norm_mri_ssp585<- mdp_mri_avg_f$MDP - mean(mdp_mri_avg_h$MDP)
lm_370_mri<- lm(norm_mri_ssp370~f_yr-1)
lm_585_mri<- lm(norm_mri_ssp585~f_yr-1)
trend_mri$slope<- c(lm_370_mri$coefficients,lm_585_mri$coefficients)
#trend_mri$p.value<- c(summary(lm_370_mri)$coefficients[,4],summary(lm_585_mri)$coefficients[,4])
#4
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ec")
mdp_ec_f<- read.csv("MDP_s6_8.csv",header = TRUE)
colnames(mdp_ec_f)<- c("Superior","Ontario","Michigan","Huron","Erie")
mdp_ec_avg_f<- data.frame(apply(mdp_ec_f[,1:5],1,mean))
colnames(mdp_ec_avg_f)<- c("MDP")
mdp_ec_h<- data.frame(mdp_sup['ec_earth'],mdp_ont['ec_earth'],mdp_michigan['ec_earth'],mdp_huron['ec_earth'],mdp_erie['ec_earth'])
mdp_ec_avg_h<- data.frame(apply(mdp_ec_h[,1:5],1,mean))
colnames(mdp_ec_avg_h)<- c("MDP")
year<- seq(1979,2100,1)
mdp_ec<- rbind(mdp_ec_avg_h,mdp_ec_avg_f)
mdp_ec$year<- year
mdp_ec$model<- rep("EC_EARTH",122)
mdp_ec$timeline<- Timeline$Type

setwd("G:/LCS-Filer/ekcarter_r/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/ec")
mdp_ec_ssp370<- read.csv("MDP_s6_8.csv",header = TRUE)
colnames(mdp_ec_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
mdp_ec_avg_ssp370<- data.frame(apply(mdp_ec_ssp370[,1:5],1,mean))
colnames(mdp_ec_avg_ssp370)<- c("MDP")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
mdp_ec_avg_ssp370$year<- year_370
mdp_ec_avg_ssp370$timeline<- fut_370
mdp_ec_avg_ssp370$model<- rep("EC_EARTH",86)
mdp_ec<- rbind(mdp_ec,mdp_ec_avg_ssp370)

trend_ec<- data.frame(rep(mean(mdp_ec_avg_h$MDP),2))
colnames(trend_ec)<-c("Intercept")
trend_ec$Model<- rep("EC_EARTH",2)
trend_ec$timeline<- c("SSP3-7.0","SSP5-8.5")


norm_ec_ssp370<- mdp_ec_avg_ssp370$MDP - mean(mdp_ec_avg_h$MDP)
norm_ec_ssp585<- mdp_ec_avg_f$MDP - mean(mdp_ec_avg_h$MDP)
lm_370_ec<- lm(norm_ec_ssp370~f_yr-1)
lm_585_ec<- lm(norm_ec_ssp585~f_yr-1)
trend_ec$slope<- c(lm_370_ec$coefficients,lm_585_ec$coefficients)
#trend_ec$p.value<- c(summary(lm_370_ec)$coefficients[,4],summary(lm_585_ec)$coefficients[,4])

#5
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/miroc")
mdp_miroc_f<- read.csv("MDP_s6_8.csv",header = TRUE)
colnames(mdp_miroc_f)<- c("Superior","Ontario","Michigan","Huron","Erie")
mdp_miroc_avg_f<- data.frame(apply(mdp_miroc_f[,1:5],1,mean))
colnames(mdp_miroc_avg_f)<- c("MDP")
mdp_miroc_h<- data.frame(mdp_sup['miroc'],mdp_ont['miroc'],mdp_michigan['miroc'],mdp_huron['miroc'],mdp_erie['miroc'])
mdp_miroc_avg_h<- data.frame(apply(mdp_miroc_h[,1:5],1,mean))
colnames(mdp_miroc_avg_h)<- c("MDP")
year<- seq(1979,2100,1)
mdp_miroc<- rbind(mdp_miroc_avg_h,mdp_miroc_avg_f)
mdp_miroc$year<- year
mdp_miroc$model<- rep("MIROC",122)
mdp_miroc$timeline<- Timeline$Type

setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/miroc")
mdp_miroc_ssp370<- read.csv("MDP_s6_8.csv",header = TRUE)
colnames(mdp_miroc_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
mdp_miroc_avg_ssp370<- data.frame(apply(mdp_miroc_ssp370[,1:5],1,mean))
colnames(mdp_miroc_avg_ssp370)<- c("MDP")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
mdp_miroc_avg_ssp370$year<- year_370
mdp_miroc_avg_ssp370$timeline<- fut_370
mdp_miroc_avg_ssp370$model<- rep("MIROC",86)
mdp_miroc<- rbind(mdp_miroc,mdp_miroc_avg_ssp370)

trend_miroc<- data.frame(rep(mean(mdp_miroc_avg_h$MDP),2))
colnames(trend_miroc)<-c("Intercept")
trend_miroc$Model<- rep("MIROC",2)
trend_miroc$timeline<- c("SSP3-7.0","SSP5-8.5")
f_yr<- seq(1,86,1)

norm_miroc_ssp370<- mdp_miroc_avg_ssp370$MDP - mean(mdp_miroc_avg_h$MDP)
norm_miroc_ssp585<- mdp_miroc_avg_f$MDP - mean(mdp_miroc_avg_h$MDP)
lm_370_miroc<- lm(norm_miroc_ssp370~f_yr-1)
lm_585_miroc<- lm(norm_miroc_ssp585~f_yr-1)
trend_miroc$slope<- c(lm_370_miroc$coefficients,lm_585_miroc$coefficients)
#trend_miroc$p.value<- c(summary(lm_370_miroc)$coefficients[,4],summary(lm_585_miroc)$coefficients[,4])
mdp_all<- rbind(mdp_ac,mdp_ec,mdp_miroc,mdp_mpi,mdp_mri)

setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/cpc")
lakes<- c("Superior","Ontario","Michigan","Huron","Erie")
mdp_cpc<- read.csv("MDP_s6_8.csv",header = TRUE)
mdp_cpc_avg<- data.frame(apply(mdp_cpc[,1:5],1,mean))
colnames(mdp_cpc_avg)<- c("MDP")
year<- seq(1979,2014,1)
mdp_cpc_avg$year<- year
tl<- rep('Observed',36)
mdp_cpc_avg$timeline<- tl
mdp_cpc_all<- rbind(mdp_cpc_avg,mdp_cpc_avg,mdp_cpc_avg,mdp_cpc_avg,mdp_cpc_avg)
model<- c(rep('ACCESS',36),rep('EC_EARTH',36),rep('MIROC',36),rep('MPI',36),rep('MRI',36))
mdp_cpc_all$model<- model
mdp_all<- rbind(mdp_all,mdp_cpc_all)

#making the dataframe for trends
trend_all<- rbind(trend_ac,trend_ec,trend_miroc,trend_mpi,trend_mri)
trend_all$year<- rep(2014,10)
trend_all$end<- rep(2100,10)
#adding 2014 to the cwd_dataframe (for ggplot)
mdp_int<- trend_all%>%
  select(-"slope",-"end")
colnames(mdp_int)<- c("MDP","model",'timeline','year')
mdp<- rbind(mdp_all,mdp_int)

trend_final<- trend_all%>%
  select(-'end',-'year')
colnames(trend_final)<- c('intercept','model','timeline','slope')
mdp_emission<- mdp[mdp$timeline%in%c('SSP3-7.0','SSP5-8.5'),]
mdp_join<- inner_join(mdp_emission,trend_final,by=c('timeline','model'))
mdp_join$x<- mdp_join$year-2014
mdp_join$y<- (mdp_join$slope*mdp_join$x)+ mdp_join$intercept

se<- mdp_join%>%
  group_by(model,timeline)%>%
  summarise(std.er= std.error(y))
mdp_join_all<- inner_join(mdp_join,se,by=c('model','timeline'))
mdp_join_all$down<- mdp_join_all$y-(1.96*mdp_join_all$std.er)
mdp_join_all$up<- mdp_join_all$y + (1.96*mdp_join_all$std.er)
mdp_join_all$fy<- mdp_join_all$year
mdp_ribbon<- mdp_join_all%>%select(MDP,model,fy,timeline,up,down)

mdp_join_all$norm<-mdp_join_all$MDP - mdp_join_all$intercept
mdp_trend_df<- data.frame(mdp_join_all$model,mdp_join_all$timeline,mdp_join_all$norm)
colnames(mdp_trend_df)<- c('model','timeline','norm')
mdp_tau<- mdp_trend_df %>%
  group_by(model, timeline) %>%
  filter(n() > 1) %>%
  summarize(tau = (MannKendall(norm)$tau))
mdp_pvalue<-mdp_trend_df %>%
  group_by(model, timeline) %>%
  filter(n() > 1) %>%
  summarize(pvalue = (MannKendall(norm)$sl))

yr<- c(2050,2050)
yr_r<- rep(yr,5)
mdp_p<- c(40,10)
mdp_p_r<- rep(mdp_p,5)
mdp_t<-c (45,15)
mdp_t_r<- rep(mdp_t,5)
mdp_pvalue$year<- yr_r
mdp_pvalue$MDP<- mdp_p_r
mdp_tau$year<- yr_r
mdp_tau$MDP<- mdp_t_r
mdp_tau$slope<- trend_all$slope

mdp_pvalue$p.value<- c(summary(lm_370)$coefficients[,4],summary(lm_585)$coefficients[,4],summary(lm_370_ec)$coefficients[,4],summary(lm_585_ec)$coefficients[,4],summary(lm_370_miroc)$coefficients[,4],summary(lm_585_miroc)$coefficients[,4],summary(lm_370_mpi)$coefficients[,4],summary(lm_585_mpi)$coefficients[,4],summary(lm_370_mri)$coefficients[,4],summary(lm_370_mri)$coefficients[,4])
#cs<- c('Historical'= 'red','Observed'='black','SSP3-7.0'='purple','SSP5-8.5'='navyblue')
ggplot(data=mdp,aes(x=year,y=MDP,fill=timeline,colour=timeline))+
  geom_line(alpha=1)+
  xlim(c(1979,2100))+
  geom_segment(data = trend_final,aes(x=2014,xend=2100,y=intercept,yend=(intercept+slope*86),color=timeline))+
  geom_ribbon(data=mdp_ribbon,aes(x=fy,ymin=down,ymax=up,fill=timeline),alpha=0.1)+
  facet_wrap(~factor(model,levels=c('EC_EARTH','MPI','MRI','ACCESS','MIROC')))+
  #scale_color_manual(values=cs)+
  #scale_fill_manual(values=cs)+
  geom_vline(xintercept = 2014, linetype="solid", 
             color = "red", size=1)+
  geom_text(aes(x=year,y=MDP, label = paste("p.value=",round(p.value,8)),colour=timeline), data = mdp_pvalue, size = 4)+
  geom_text(aes(x=year,y=MDP, label = paste("slope=",round(slope,3),"mm/day/year"),colour=timeline), data = mdp_tau, size = 4)+
  theme_bw()+
  
  theme(plot.background = element_blank(),
        panel.grid.major =element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(),
        strip.background = element_rect(fill='white'),
        strip.text = element_text(face='bold',size = 16),
        axis.title.y = element_text(face = 'bold',size=16),
        plot.title=element_text(size=16,face='bold'),legend.title = element_text(size = 16,face='bold'),legend.text = element_text(size=16,face='bold'))+
  ylab('MDP(mm/day)')+
  ggtitle('Maximum Daily Precipitation(MDP)')+
  coord_cartesian(expand = FALSE, #turn off axis expansion (padding)
                  xlim = c(1979,2100),ylim=c(0,50))
  
setwd("E:/MW_ClimateChange/Data for frontiers paper/Draft/Edits")
ggsave("mdp_detrend_slope_p.jpeg",width = 12, height=8)
