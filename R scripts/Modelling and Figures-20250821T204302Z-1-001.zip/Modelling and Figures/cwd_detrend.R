library(ggplot2)
library(tidyverse)
library(reshape2)
library(plotrix)
library(Kendall)
lakes<- c("Superior","Ontario","Michigan","Huron","Erie")
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/acess")
cwd_ac_f<- read.csv("CWD_s6_8.csv",header = FALSE)
cwd_ac_avg_f<- data.frame(apply(cwd_ac_f[,1:5],1,mean))
colnames(cwd_ac_avg_f)<- c("CWD")

setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Superior/Summer")
cwd_sup<- read.csv("CWD_s6_8.csv")

setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Ontario/Summer")
cwd_ont<- read.csv("CwD_s6_8.csv")

setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Michigan/Summer")
cwd_michigan<- read.csv("CWD_s6_8.csv")

setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Huron/Summer")
cwd_huron<- read.csv("CWD_s6_8.csv")
setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Erie/Summer")
cwd_erie<- read.csv("CWD_s6_8.csv")

cwd_ac_h<- data.frame(cwd_sup['access'],cwd_ont['access'],cwd_michigan['access'],cwd_huron['access'],cwd_erie['access'])
colnames(cwd_ac_h)<- c("Superior","Ontario","Michigan","Huron","Erie")
cwd_ac_avg_h<- data.frame(apply(cwd_ac_h[,1:5],1,mean))
colnames(cwd_ac_avg_h)<- c("CWD")
year<- seq(1979,2100,1)
cwd_ac<- rbind(cwd_ac_avg_h,cwd_ac_avg_f)
cwd_ac$year<- year
cwd_ac$model<- rep("ACCESS",122)
hist<- data.frame(rep("Historical",36))
fut<- data.frame(rep("SSP5-8.5",86))
colnames(hist)<- colnames(fut)<- c("Type")
Timeline<- rbind(hist,fut)
cwd_ac$timeline<- Timeline$Type

setwd("G:/LCS-Filer/ekcarter_r/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/acess")
cwd_ac_ssp370<- read.csv("CWD_s6_8.csv",header = TRUE)
colnames(cwd_ac_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
cwd_ac_avg_ssp370<- data.frame(apply(cwd_ac_ssp370[,1:5],1,mean))
colnames(cwd_ac_avg_ssp370)<- c("CWD")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
cwd_ac_avg_ssp370$year<- year_370
cwd_ac_avg_ssp370$timeline<- fut_370
cwd_ac_avg_ssp370$model<- rep("ACCESS",86)
cwd_ac<- rbind(cwd_ac,cwd_ac_avg_ssp370)

trend_ac<- data.frame(rep(mean(cwd_ac_avg_h$CWD),2))
colnames(trend_ac)<- c("Intercept")
trend_ac$Model<- rep("ACCESS",2)
trend_ac$timeline<- c("SSP3-7.0","SSP5-8.5")
f_yr<- seq(1,86,1)

norm_ac_ssp370<- cwd_ac_avg_ssp370$CWD - mean(cwd_ac_avg_h$CWD)
norm_ac_ssp585<- cwd_ac_avg_f$CWD - mean(cwd_ac_avg_h$CWD)
lm_370<- lm(norm_ac_ssp370 ~ f_yr-1)
lm_585<- lm(norm_ac_ssp585~f_yr-1)
trend_ac$slope<- c(lm_370$coefficients,lm_585$coefficients)
#2
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/mpi")
cwd_mpi_f<- read.csv("CWD_s6_8.csv",header = TRUE)
colnames(cwd_mpi_f)<- c("Superior","Ontario","Michigan","Huron","Erie")
cwd_mpi_avg_f<- data.frame(apply(cwd_mpi_f[,1:5],1,mean))
colnames(cwd_mpi_avg_f)<- c("CWD")
cwd_mpi_h<- data.frame(cwd_sup['mpi'],cwd_ont['mpi'],cwd_michigan['mpi'],cwd_huron['mpi'],cwd_erie['mpi'])
cwd_mpi_avg_h<- data.frame(apply(cwd_mpi_h[,1:5],1,mean))
colnames(cwd_mpi_avg_h)<- c("CWD")
year<- seq(1979,2100,1)
cwd_mpi<- rbind(cwd_mpi_avg_h,cwd_mpi_avg_f)
cwd_mpi$year<- year
cwd_mpi$model<- rep("MPI",122)
cwd_mpi$timeline<- Timeline$Type

setwd("G:/LCS-Filer/ekcarter_r/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/mpi")
cwd_mpi_ssp370<- read.csv("CWD_s6_8.csv",header = FALSE)
colnames(cwd_mpi_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
cwd_mpi_avg_ssp370<- data.frame(apply(cwd_mpi_ssp370[,1:5],1,mean))
colnames(cwd_mpi_avg_ssp370)<- c("CWD")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
cwd_mpi_avg_ssp370$year<- year_370
cwd_mpi_avg_ssp370$timeline<- fut_370
cwd_mpi_avg_ssp370$model<- rep("MPI",86)
cwd_mpi<- rbind(cwd_mpi,cwd_mpi_avg_ssp370)

trend_mpi<- data.frame(rep(mean(cwd_mpi_avg_h$CWD),2))
colnames(trend_mpi)<- c("Intercept")
trend_mpi$Model<- rep("MPI",2)
trend_mpi$timeline<- c("SSP3-7.0","SSP5-8.5")


norm_mpi_ssp370<- cwd_mpi_avg_ssp370$CWD - mean(cwd_mpi_avg_h$CWD)
norm_mpi_ssp585<- cwd_mpi_avg_f$CWD - mean(cwd_mpi_avg_h$CWD)
lm_370_mpi<- lm(norm_mpi_ssp370~f_yr-1)
lm_585_mpi<- lm(norm_mpi_ssp585~f_yr-1)
trend_mpi$slope<- c(lm_370_mpi$coefficients,lm_585_mpi$coefficients)

#mri
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/mri")
cwd_mri_f<- read.csv("CWD_s6_8.csv",header = FALSE)
colnames(cwd_mri_f)<- c("Superior","Ontario","Michigan","Huron","Erie")
cwd_mri_avg_f<- data.frame(apply(cwd_mri_f[,1:5],1,mean))
colnames(cwd_mri_avg_f)<- c("CWD")
cwd_mri_h<- data.frame(cwd_sup['mri'],cwd_ont['mri'],cwd_michigan['mri'],cwd_huron['mri'],cwd_erie['mri'])
cwd_mri_avg_h<- data.frame(apply(cwd_mri_h[,1:5],1,mean))
colnames(cwd_mri_avg_h)<- c("CWD")
year<- seq(1979,2100,1)
cwd_mri<- rbind(cwd_mri_avg_h,cwd_mri_avg_f)
cwd_mri$year<- year
cwd_mri$model<- rep("MRI",122)
cwd_mri$timeline<- Timeline$Type

setwd("G:/LCS-Filer/ekcarter_r/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/mri")
cwd_mri_ssp370<- read.csv("CWD_s6_8.csv",header = FALSE)
colnames(cwd_mri_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
cwd_mri_avg_ssp370<- data.frame(apply(cwd_mri_ssp370[,1:5],1,mean))
colnames(cwd_mri_avg_ssp370)<- c("CWD")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
cwd_mri_avg_ssp370$year<- year_370
cwd_mri_avg_ssp370$timeline<- fut_370
cwd_mri_avg_ssp370$model<- rep("MRI",86)
cwd_mri<- rbind(cwd_mri,cwd_mri_avg_ssp370)

trend_mri<- data.frame(rep(mean(cwd_mri_avg_h$CWD),2))
colnames(trend_mri)<-c("Intercept")
trend_mri$Model<- rep("MRI",2)
trend_mri$timeline<- c("SSP3-7.0","SSP5-8.5")


norm_mri_ssp370<- cwd_mri_avg_ssp370$CWD - mean(cwd_mri_avg_h$CWD)
norm_mri_ssp585<- cwd_mri_avg_f$CWD - mean(cwd_mri_avg_h$CWD)
lm_370_mri<- lm(norm_mri_ssp370~f_yr-1)
lm_585_mri<- lm(norm_mri_ssp585~f_yr-1)
trend_mri$slope<- c(lm_370_mri$coefficients,lm_585_mri$coefficients)

#4
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ec")
cwd_ec_f<- read.csv("CWD_s6_8.csv",header = TRUE)
colnames(cwd_ec_f)<- c("Superior","Ontario","Michigan","Huron","Erie")
cwd_ec_avg_f<- data.frame(apply(cwd_ec_f[,1:5],1,mean))
colnames(cwd_ec_avg_f)<- c("CWD")
cwd_ec_h<- data.frame(cwd_sup['ec_earth'],cwd_ont['ec_earth'],cwd_michigan['ec_earth'],cwd_huron['ec_earth'],cwd_erie['ec_earth'])
cwd_ec_avg_h<- data.frame(apply(cwd_ec_h[,1:5],1,mean))
colnames(cwd_ec_avg_h)<- c("CWD")
year<- seq(1979,2100,1)
cwd_ec<- rbind(cwd_ec_avg_h,cwd_ec_avg_f)
cwd_ec$year<- year
cwd_ec$model<- rep("EC_EARTH",122)
cwd_ec$timeline<- Timeline$Type

setwd("G:/LCS-Filer/ekcarter_r/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/ec")
cwd_ec_ssp370<- read.csv("CWD_s6_8.csv",header = TRUE)
colnames(cwd_ec_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
cwd_ec_avg_ssp370<- data.frame(apply(cwd_ec_ssp370[,1:5],1,mean))
colnames(cwd_ec_avg_ssp370)<- c("CWD")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
cwd_ec_avg_ssp370$year<- year_370
cwd_ec_avg_ssp370$timeline<- fut_370
cwd_ec_avg_ssp370$model<- rep("EC_EARTH",86)
cwd_ec<- rbind(cwd_ec,cwd_ec_avg_ssp370)

trend_ec<- data.frame(rep(mean(cwd_ec_avg_h$CWD),2))
colnames(trend_ec)<-c("Intercept")
trend_ec$Model<- rep("EC_EARTH",2)
trend_ec$timeline<- c("SSP3-7.0","SSP5-8.5")


norm_ec_ssp370<- cwd_ec_avg_ssp370$CWD - mean(cwd_ec_avg_h$CWD)
norm_ec_ssp585<- cwd_ec_avg_f$CWD - mean(cwd_ec_avg_h$CWD)
lm_370_ec<- lm(norm_ec_ssp370~f_yr-1)
lm_585_ec<- lm(norm_ec_ssp585~f_yr-1)
trend_ec$slope<- c(lm_370_ec$coefficients,lm_585_ec$coefficients)


#5
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/miroc")
cwd_miroc_f<- read.csv("CWD_s6_8.csv",header = TRUE)
colnames(cwd_miroc_f)<- c("Superior","Ontario","Michigan","Huron","Erie")
cwd_miroc_avg_f<- data.frame(apply(cwd_miroc_f[,1:5],1,mean))
colnames(cwd_miroc_avg_f)<- c("CWD")
cwd_miroc_h<- data.frame(cwd_sup['miroc'],cwd_ont['miroc'],cwd_michigan['miroc'],cwd_huron['miroc'],cwd_erie['miroc'])
cwd_miroc_avg_h<- data.frame(apply(cwd_miroc_h[,1:5],1,mean))
colnames(cwd_miroc_avg_h)<- c("CWD")
year<- seq(1979,2100,1)
cwd_miroc<- rbind(cwd_miroc_avg_h,cwd_miroc_avg_f)
cwd_miroc$year<- year
cwd_miroc$model<- rep("MIROC",122)
cwd_miroc$timeline<- Timeline$Type

setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/miroc")
cwd_miroc_ssp370<- read.csv("CWD_s6_8.csv",header = TRUE)
colnames(cwd_miroc_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
cwd_miroc_avg_ssp370<- data.frame(apply(cwd_miroc_ssp370[,1:5],1,mean))
colnames(cwd_miroc_avg_ssp370)<- c("CWD")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
cwd_miroc_avg_ssp370$year<- year_370
cwd_miroc_avg_ssp370$timeline<- fut_370
cwd_miroc_avg_ssp370$model<- rep("MIROC",86)
cwd_miroc<- rbind(cwd_miroc,cwd_miroc_avg_ssp370)

trend_miroc<- data.frame(rep(mean(cwd_miroc_avg_h$CWD),2))
colnames(trend_miroc)<-c("Intercept")
trend_miroc$Model<- rep("MIROC",2)
trend_miroc$timeline<- c("SSP3-7.0","SSP5-8.5")
f_yr<- seq(1,86,1)

norm_miroc_ssp370<- cwd_miroc_avg_ssp370$CWD - mean(cwd_miroc_avg_h$CWD)
norm_miroc_ssp585<- cwd_miroc_avg_f$CWD - mean(cwd_miroc_avg_h$CWD)
lm_370_miroc<- lm(norm_miroc_ssp370~f_yr-1)
lm_585_miroc<- lm(norm_miroc_ssp585~f_yr-1)
trend_miroc$slope<- c(lm_370_miroc$coefficients,lm_585_miroc$coefficients)

cwd_all<- rbind(cwd_ac,cwd_mpi,cwd_mri,cwd_ec,cwd_miroc)
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/cpc")
lakes<- c("Superior","Ontario","Michigan","Huron","Erie")
cwd_cpc<- read.csv("CWD_s6_8.csv",header = TRUE)
cwd_cpc_avg<- data.frame(apply(cwd_cpc[,1:5],1,mean))
colnames(cwd_cpc_avg)<- c("CWD")
year<- seq(1979,2014,1)
cwd_cpc_avg$year<- year
tl<- rep('Observed',36)
cwd_cpc_avg$timeline<- tl
cwd_cpc_all<- rbind(cwd_cpc_avg,cwd_cpc_avg,cwd_cpc_avg,cwd_cpc_avg,cwd_cpc_avg)
model<- c(rep('ACCESS',36),rep('EC_EARTH',36),rep('MIROC',36),rep('MPI',36),rep('MRI',36))
cwd_cpc_all$model<- model
cwd_all<- rbind(cwd_all,cwd_cpc_all)

#making the dataframe for trends
trend_all<- rbind(trend_ac,trend_ec,trend_miroc,trend_mpi,trend_mri)
colnames(trend_all)<- c("Intercept","Model","Timeline","slope")

trend_all$year<- rep(2014,10)
trend_all$end<- rep(2100,10)
#adding 2014 to the cwd_dataframe (for ggplot)
cwd_int<- trend_all%>%
  select(-"slope",-"end")
colnames(cwd_int)<- c("CWD","model",'timeline','year')
cwd<- rbind(cwd_all,cwd_int)

#for geom_segment
trend_final<- trend_all%>%
  select(-'end',-'year')
colnames(trend_final)<- c('intercept','model','timeline','slope')
cwd_emission<- cwd[cwd$timeline%in%c('SSP3-7.0','SSP5-8.5'),]
cwd_join<- inner_join(cwd_emission,trend_final,by=c('timeline','model'))
cwd_join$x<- cwd_join$year-2014
cwd_join$y<- (cwd_join$slope*cwd_join$x)+ cwd_join$intercept

#standard error calculation
se<- cwd_join%>%
  group_by(model,timeline)%>%
  summarise(std.er= std.error(y))

sd<- cwd_join%>%
  group_by(model,timeline)%>%
  summarise(std.er= sd(y))
#dataframe for geom_ribbon
cwd_join_all<- inner_join(cwd_join,se,by=c('model','timeline'))
cwd_join_all$down<- cwd_join_all$y-(1.96*cwd_join_all$std.er)
cwd_join_all$up<- cwd_join_all$y + (1.96*cwd_join_all$std.er)
cwd_join_all$fy<- cwd_join_all$year
cwd_ribbon<- cwd_join_all%>%select(CWD,model,fy,timeline,up,down)

cwd_join_all$norm<-cwd_join_all$CWD - cwd_join_all$intercept
cwd_trend_df<- data.frame(cwd_join_all$model,cwd_join_all$timeline,cwd_join_all$norm)
colnames(cwd_trend_df)<- c('model','timeline','norm')
cwd_tau<- cwd_trend_df %>%
  group_by(model, timeline) %>%
  filter(n() > 1) %>%
  summarize(tau = (MannKendall(norm)$tau))
cwd_pvalue<-cwd_trend_df %>%
  group_by(model, timeline) %>%
  filter(n() > 1) %>%
  summarize(pvalue = (MannKendall(norm)$sl))
yr<- c(2050,2050)
yr_r<- rep(yr,5)
cwd_p<- c(20,1)
cwd_p_r<- rep(cwd_p,5)
cwd_t<-c (22,3)
cwd_t_r<- rep(cwd_t,5)
cwd_pvalue$year<- yr_r
cwd_pvalue$CWD<- cwd_p_r
cwd_tau$year<- yr_r
cwd_tau$CWD<- cwd_t_r
cwd_tau$slope<- trend_all$slope

cwd_pvalue$p.value<- c(summary(lm_370)$coefficients[,4],summary(lm_585)$coefficients[,4],summary(lm_370_ec)$coefficients[,4],summary(lm_585_ec)$coefficients[,4],summary(lm_370_miroc)$coefficients[,4],summary(lm_585_miroc)$coefficients[,4],summary(lm_370_mpi)$coefficients[,4],summary(lm_585_mpi)$coefficients[,4],summary(lm_370_mri)$coefficients[,4],summary(lm_370_mri)$coefficients[,4])
cs<- c('Historical'= 'red','Observed'='black','SSP3-7.0'='purple','SSP5-8.5'='navyblue')
ggplot(data=cwd,aes(x=year,y=CWD,fill=timeline,colour=timeline))+
  geom_line()+
  geom_segment(data = trend_final,aes(x=2014,xend=2100,y=intercept,yend=(intercept+slope*86),color=timeline),alpha=1)+
  geom_ribbon(data=cwd_ribbon,aes(x=fy,ymin=down,ymax=up,fill=timeline),alpha=0.5)+
  facet_wrap(~factor(model,levels=c('EC_EARTH','MPI','MRI','ACCESS','MIROC')))+
  #scale_color_manual(values = cs)+
  #scale_fill_manual(values = cs)+
  geom_vline(xintercept = 2014, linetype="solid", 
             color = "red", size=1)+
  geom_text(aes(x=year,y=CWD, label = paste("p.value=",round(p.value,3)),colour=timeline), data = cwd_pvalue, size = 3,fontface='bold')+
  geom_text(aes(x=year,y=CWD, label = paste("slope=",round(slope,3),'day/year'),colour=timeline), data = cwd_tau, size = 3,fontface='bold')+
  theme_bw()+
  
  theme(plot.background = element_blank(),
        panel.grid.major =element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(),
        strip.background = element_rect(fill='white'),
        strip.text = element_text(face='bold',size = 16),
        axis.title.y = element_text(face = 'bold',size=16),
        plot.title=element_text(size=14,face='bold'),legend.title = element_text(size = 14,face='bold'),legend.text = element_text(size=14,face='bold'))+
  ylab('CWD(Days)')+
  ggtitle('Cumulative Wet Days (CWD)')+
  ylim(c(0,25))+
  coord_cartesian(expand = FALSE, #turn off axis expansion (padding)
                  xlim = c(1979,2100), ylim = c(0,25))
  

setwd("E:/MW_ClimateChange/Data for frontiers paper/Draft/Edits")
ggsave("cwd_detrend_slope_p.jpeg",width = 12, height=8)
