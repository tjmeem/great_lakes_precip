#cdd
library(reshape2)
library(ggplot2)
library(tidyverse)
library(plotrix)
library(Kendall)
lakes<- c("Superior","Ontario","Michigan","Huron","Erie")
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/acess")
cdd_ac_f<- read.csv("CDD_s6_8.csv",header = FALSE)
cdd_ac_avg_f<- data.frame(apply(cdd_ac_f[,1:5],1,mean))
colnames(cdd_ac_avg_f)<- c("CDD")

setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Superior/Summer")
cdd_sup<- read.csv("CDD_s6_8.csv")

setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Ontario/Summer")
cdd_ont<- read.csv("CDD_s6_8.csv")

setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Michigan/Summer")
cdd_michigan<- read.csv("CDD_s6_8.csv")

setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Huron/Summer")
cdd_huron<- read.csv("CDD_s6_8.csv")
setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Erie/Summer")
cdd_erie<- read.csv("CDD_s6_8.csv")

setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/acess")
cdd_ac_f<- read.csv("CDD_s6_8.csv",header = FALSE)
colnames(cdd_ac_f)<- c("Superior","Ontario","Michigan","Huron","Erie")
cdd_ac_avg_f<- data.frame(apply(cdd_ac_f[,1:5],1,mean))
colnames(cdd_ac_avg_f)<- c("CDD")

cdd_ac_h<- data.frame(cdd_sup['access'],cdd_ont['access'],cdd_michigan['access'],cdd_huron['access'],cdd_erie['access'])
cdd_ac_avg_h<- data.frame(apply(cdd_ac_h[,1:5],1,mean))
colnames(cdd_ac_avg_h)<- c("CDD")


year<- seq(1979,2100,1)
cdd_ac<- rbind(cdd_ac_avg_h,cdd_ac_avg_f)
cdd_ac$year<- year
cdd_ac$model<- rep("ACCESS",122)

hist<- data.frame(rep("Historical",36))
fut<- data.frame(rep("SSP5-8.5",86))
colnames(hist)<- colnames(fut)<- c("Type")
Timeline<- rbind(hist,fut)
cdd_ac$timeline<- Timeline$Type



setwd("G:/LCS-Filer/ekcarter_r/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/acess")
cdd_ac_ssp370<- read.csv("CDD_s6_8.csv",header = TRUE)
colnames(cdd_ac_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
cdd_ac_avg_ssp370<- data.frame(apply(cdd_ac_ssp370[,1:5],1,mean))
colnames(cdd_ac_avg_ssp370)<- c("CDD")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
cdd_ac_avg_ssp370$year<- year_370
cdd_ac_avg_ssp370$timeline<- fut_370

cdd_ac_avg_ssp370$model<- rep("ACCESS",86)
cdd_ac<- rbind(cdd_ac,cdd_ac_avg_ssp370)
trend<- data.frame(rep(mean(cdd_ac_avg_h$CDD),2))
colnames(trend)<- c("Intercept")
trend$Model<- rep("ACCESS",2)
trend$timeline<- c("SSP3-7.0","SSP5-8.5")
f_yr<- seq(1,86,1)

norm_ac_ssp370<- cdd_ac_avg_ssp370$CDD - mean(cdd_ac_avg_h$CDD)
norm_ac_ssp585<- cdd_ac_avg_f$CDD - mean(cdd_ac_avg_h$CDD)
lm_370<- lm(norm_ac_ssp370 ~ f_yr-1)
lm_585<- lm(norm_ac_ssp585~f_yr-1)
trend$slope<- c(lm_370$coefficients,lm_585$coefficients)
#2
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/mpi")
cdd_mpi_f<- read.csv("CDD_s6_8.csv",header = TRUE)
colnames(cdd_mpi_f)<- c("Superior","Ontario","Michigan","Huron","Erie")
cdd_mpi_avg_f<- data.frame(apply(cdd_mpi_f[,1:5],1,mean))
colnames(cdd_mpi_avg_f)<- c("CDD")
cdd_mpi_h<- data.frame(cdd_sup['mpi'],cdd_ont['mpi'],cdd_michigan['mpi'],cdd_huron['mpi'],cdd_erie['mpi'])
cdd_mpi_avg_h<- data.frame(apply(cdd_mpi_h[,1:5],1,mean))
colnames(cdd_mpi_avg_h)<- c("CDD")

year<- seq(1979,2100,1)
cdd_mpi<- rbind(cdd_mpi_avg_h,cdd_mpi_avg_f)
cdd_mpi$year<- year
cdd_mpi$model<- rep("MPI",122)
cdd_mpi$timeline<- Timeline$Type
setwd("G:/LCS-Filer/ekcarter_r/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/mpi")
cdd_mpi_ssp370<- read.csv("CDD_s6_8.csv",header = FALSE)
colnames(cdd_mpi_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
cdd_mpi_avg_ssp370<- data.frame(apply(cdd_mpi_ssp370[,1:5],1,mean))
colnames(cdd_mpi_avg_ssp370)<- c("CDD")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
cdd_mpi_avg_ssp370$year<- year_370
cdd_mpi_avg_ssp370$timeline<- fut_370
cdd_mpi_avg_ssp370$model<- rep("MPI",86)
cdd_mpi<- rbind(cdd_mpi,cdd_mpi_avg_ssp370)
trend_mpi<- data.frame(rep(mean(cdd_mpi_avg_h$CDD),2))
colnames(trend_mpi)<- c("Intercept")
trend_mpi$Model<- rep("MPI",2)
trend_mpi$timeline<- c("SSP3-7.0","SSP5-8.5")


norm_mpi_ssp370<- cdd_mpi_avg_ssp370$CDD - mean(cdd_mpi_avg_h$CDD)
norm_mpi_ssp585<- cdd_mpi_avg_f$CDD - mean(cdd_mpi_avg_h$CDD)
lm_370_mpi<- lm(norm_mpi_ssp370~f_yr-1)
lm_585_mpi<- lm(norm_mpi_ssp585~f_yr-1)
trend_mpi$slope<- c(lm_370_mpi$coefficients,lm_585_mpi$coefficients)
#3
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/mri")
cdd_mri_f<- read.csv("CDD_s6_8.csv",header = FALSE)
colnames(cdd_mri_f)<- c("Superior","Ontario","Michigan","Huron","Erie")
cdd_mri_avg_f<- data.frame(apply(cdd_mri_f[,1:5],1,mean))
colnames(cdd_mri_avg_f)<- c("CDD")
cdd_mri_h<- data.frame(cdd_sup['mri'],cdd_ont['mri'],cdd_michigan['mri'],cdd_huron['mri'],cdd_erie['mri'])
cdd_mri_avg_h<- data.frame(apply(cdd_mri_h[,1:5],1,mean))
colnames(cdd_mri_avg_h)<- c("CDD")
year<- seq(1979,2100,1)
cdd_mri<- rbind(cdd_mri_avg_h,cdd_mri_avg_f)
cdd_mri$year<- year
cdd_mri$model<- rep("MRI",122)
cdd_mri$timeline<- Timeline$Type
setwd("G:/LCS-Filer/ekcarter_r/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/mri")
cdd_mri_ssp370<- read.csv("CDD_s6_8.csv",header = FALSE)
colnames(cdd_mri_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
cdd_mri_avg_ssp370<- data.frame(apply(cdd_mri_ssp370[,1:5],1,mean))
colnames(cdd_mri_avg_ssp370)<- c("CDD")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
cdd_mri_avg_ssp370$year<- year_370
cdd_mri_avg_ssp370$timeline<- fut_370
cdd_mri_avg_ssp370$model<- rep("MRI",86)
cdd_mri<- rbind(cdd_mri,cdd_mri_avg_ssp370)
trend_mri<- data.frame(rep(mean(cdd_mri_avg_h$CDD),2))
colnames(trend_mri)<-c("Intercept")
trend_mri$Model<- rep("MRI",2)
trend_mri$timeline<- c("SSP3-7.0","SSP5-8.5")


norm_mri_ssp370<- cdd_mri_avg_ssp370$CDD - mean(cdd_mri_avg_h$CDD)
norm_mri_ssp585<- cdd_mri_avg_f$CDD - mean(cdd_mri_avg_h$CDD)
lm_370_mri<- lm(norm_mri_ssp370~f_yr-1)
lm_585_mri<- lm(norm_mri_ssp585~f_yr-1)
trend_mri$slope<- c(lm_370_mri$coefficients,lm_585_mri$coefficients)
#4
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ec")
cdd_ec_f<- read.csv("CDD_s6_8.csv",header = TRUE)
colnames(cdd_ec_f)<- c("Superior","Ontario","Michigan","Huron","Erie")
cdd_ec_avg_f<- data.frame(apply(cdd_ec_f[,1:5],1,mean))
colnames(cdd_ec_avg_f)<- c("CDD")
cdd_ec_h<- data.frame(cdd_sup['ec_earth'],cdd_ont['ec_earth'],cdd_michigan['ec_earth'],cdd_huron['ec_earth'],cdd_erie['ec_earth'])
cdd_ec_avg_h<- data.frame(apply(cdd_ec_h[,1:5],1,mean))
colnames(cdd_ec_avg_h)<- c("CDD")
year<- seq(1979,2100,1)
cdd_ec<- rbind(cdd_ec_avg_h,cdd_ec_avg_f)
cdd_ec$year<- year
cdd_ec$model<- rep("EC_EARTH",122)
cdd_ec$timeline<- Timeline$Type
setwd("G:/LCS-Filer/ekcarter_r/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/ec")
cdd_ec_ssp370<- read.csv("CDD_s6_8.csv",header = TRUE)
colnames(cdd_ec_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
cdd_ec_avg_ssp370<- data.frame(apply(cdd_ec_ssp370[,1:5],1,mean))
colnames(cdd_ec_avg_ssp370)<- c("CDD")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
cdd_ec_avg_ssp370$year<- year_370
cdd_ec_avg_ssp370$timeline<- fut_370
cdd_ec_avg_ssp370$model<- rep("EC_EARTH",86)
cdd_ec<- rbind(cdd_ec,cdd_ec_avg_ssp370)

trend_ec<- data.frame(rep(mean(cdd_ec_avg_h$CDD),2))
colnames(trend_ec)<-c("Intercept")
trend_ec$Model<- rep("EC_EARTH",2)
trend_ec$timeline<- c("SSP3-7.0","SSP5-8.5")


norm_ec_ssp370<- cdd_ec_avg_ssp370$CDD - mean(cdd_ec_avg_h$CDD)
norm_ec_ssp585<- cdd_ec_avg_f$CDD - mean(cdd_ec_avg_h$CDD)
lm_370_ec<- lm(norm_ec_ssp370~f_yr-1)
lm_585_ec<- lm(norm_ec_ssp585~f_yr-1)
trend_ec$slope<- c(lm_370_ec$coefficients,lm_585_ec$coefficients)
#5
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/miroc")
cdd_miroc_f<- read.csv("CDD_s6_8.csv",header = TRUE)
colnames(cdd_miroc_f)<- c("Superior","Ontario","Michigan","Huron","Erie")
cdd_miroc_avg_f<- data.frame(apply(cdd_miroc_f[,1:5],1,mean))
colnames(cdd_miroc_avg_f)<- c("CDD")
cdd_miroc_h<- data.frame(cdd_sup['miroc'],cdd_ont['miroc'],cdd_michigan['miroc'],cdd_huron['miroc'],cdd_erie['miroc'])
cdd_miroc_avg_h<- data.frame(apply(cdd_miroc_h[,1:5],1,mean))
colnames(cdd_miroc_avg_h)<- c("CDD")
year<- seq(1979,2100,1)
cdd_miroc<- rbind(cdd_miroc_avg_h,cdd_miroc_avg_f)
cdd_miroc$year<- year
cdd_miroc$model<- rep("MIROC",122)
cdd_miroc$timeline<- Timeline$Type
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/miroc")
cdd_miroc_ssp370<- read.csv("CDD_s6_8.csv",header = TRUE)
colnames(cdd_miroc_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
cdd_miroc_avg_ssp370<- data.frame(apply(cdd_miroc_ssp370[,1:5],1,mean))
colnames(cdd_miroc_avg_ssp370)<- c("CDD")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
cdd_miroc_avg_ssp370$year<- year_370
cdd_miroc_avg_ssp370$timeline<- fut_370
cdd_miroc_avg_ssp370$model<- rep("MIROC",86)
cdd_miroc<- rbind(cdd_miroc,cdd_miroc_avg_ssp370)

trend_miroc<- data.frame(rep(mean(cdd_miroc_avg_h$CDD),2))
colnames(trend_miroc)<-c("Intercept")
trend_miroc$Model<- rep("MIROC",2)
trend_miroc$timeline<- c("SSP3-7.0","SSP5-8.5")
f_yr<- seq(1,86,1)

norm_miroc_ssp370<- cdd_miroc_avg_ssp370$CDD - mean(cdd_miroc_avg_h$CDD)
norm_miroc_ssp585<- cdd_miroc_avg_f$CDD - mean(cdd_miroc_avg_h$CDD)
lm_370_miroc<- lm(norm_miroc_ssp370~f_yr-1)
lm_585_miroc<- lm(norm_miroc_ssp585~f_yr-1)
trend_miroc$slope<- c(lm_370_miroc$coefficients,lm_585_miroc$coefficients)

cdd_all<- rbind(cdd_ac,cdd_mpi,cdd_mri,cdd_ec,cdd_miroc)

setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/cpc")
lakes<- c("Superior","Ontario","Michigan","Huron","Erie")
cdd_cpc<- read.csv("CDD_s6_8.csv",header = TRUE)
cdd_cpc_avg<- data.frame(apply(cdd_cpc[,1:5],1,mean))
cdd_cpc_avg<- data.frame(apply(cdd_cpc[,1:5],1,mean))
colnames(cdd_cpc_avg)<- c("CDD")
year<- seq(1979,2014,1)
cdd_cpc_avg$year<- year
tl<- rep('Observed',36)
cdd_cpc_avg$timeline<- tl
cdd_cpc_all<- rbind(cdd_cpc_avg,cdd_cpc_avg,cdd_cpc_avg,cdd_cpc_avg,cdd_cpc_avg)
model<- c(rep('ACCESS',36),rep('EC_EARTH',36),rep('MIROC',36),rep('MPI',36),rep('MRI',36))
cdd_cpc_all$model<- model
cdd_all<- rbind(cdd_all,cdd_cpc_all)

#making the dataframe for trends
trend_all<- rbind(trend,trend_ec,trend_miroc, trend_mpi,trend_mri)
trend_csv<- trend_all[,c(2:4)]
write.csv(trend_csv,"E:/MW_ClimateChange/Data for frontiers paper/Draft/trend_cdd.csv")
trend_all$year<- rep(2014,10)
trend_all$end<- rep(2100,10)
#adding 2014 to the cdd_dataframe (for ggplot)
cdd_int<- trend_all%>%
  select(-"slope",-"end")
colnames(cdd_int)<- c("CDD","model",'timeline','year')
cdd<- rbind(cdd_all,cdd_int)

#for geom_segment
trend_final<- trend_all%>%
  select(-'end',-'year')
colnames(trend_final)<- c('intercept','model','timeline','slope')
cdd_emission<- cdd[cdd$timeline%in%c('SSP3-7.0','SSP5-8.5'),]
cdd_join<- inner_join(cdd_emission,trend_final,by=c('timeline','model'))
cdd_join$x<- cdd_join$year-2014
cdd_join$y<- (cdd_join$slope*cdd_join$x)+ cdd_join$intercept
#standard error calculation
se<- cdd_join%>%
  group_by(model,timeline)%>%
  summarise(std.er= std.error(y))
#dataframe for geom_ribbon
cdd_join_all<- inner_join(cdd_join,se,by=c('model','timeline'))
cdd_join_all$down<- cdd_join_all$y-(1.96*cdd_join_all$std.er)
cdd_join_all$up<- cdd_join_all$y + (1.96*cdd_join_all$std.er)
cdd_join_all$fy<- cdd_join_all$year
cdd_ribbon<- cdd_join_all%>%select(CDD,model,fy,timeline,up,down)
#trend_line
cdd_join_all$norm<-cdd_join_all$CDD - cdd_join_all$intercept
cdd_trend_df<- data.frame(cdd_join_all$model,cdd_join_all$timeline,cdd_join_all$norm)
colnames(cdd_trend_df)<- c('model','timeline','norm')
cdd_tau<- cdd_trend_df %>%
  group_by(model, timeline) %>%
  filter(n() > 1) %>%
  summarize(tau = (MannKendall(norm)$tau))
cdd_pvalue<-cdd_trend_df %>%
  group_by(model, timeline) %>%
  filter(n() > 1) %>%
  summarize(pvalue = (MannKendall(norm)$sl))

cdd_pvalue$p.value<- c(summary(lm_370)$coefficients[,4],summary(lm_585)$coefficients[,4],summary(lm_370_ec)$coefficients[,4],summary(lm_585_ec)$coefficients[,4],summary(lm_370_miroc)$coefficients[,4],summary(lm_585_miroc)$coefficients[,4],summary(lm_370_mpi)$coefficients[,4],summary(lm_585_mpi)$coefficients[,4],summary(lm_370_mri)$coefficients[,4],summary(lm_370_mri)$coefficients[,4])
yr<- c(2050,2050)
yr_r<- rep(yr,5)
cdd_p<- c(10,1)
cdd_p_r<- rep(cdd_p,5)
cdd_t<-c (12,3)
cdd_t_r<- rep(cdd_t,5)
cdd_pvalue$year<- yr_r
cdd_pvalue$CDD<- cdd_p_r
cdd_tau$year<- yr_r
cdd_tau$CDD<- cdd_t_r
cdd_tau$slope<- trend_all$slope
ggplot(data=cdd,aes(x=year,y=CDD,fill=timeline,colour=timeline))+
  geom_line(alpha=1)+
  geom_segment(data = trend_final,aes(x=2014,xend=2100,y=intercept,yend=(intercept+slope*85),color=timeline),size=1)+
  geom_ribbon(data=cdd_ribbon,aes(x=fy,ymin=down,ymax=up,fill=timeline),alpha=0.1)+
  facet_wrap(~factor(model,levels=c('EC_EARTH','MPI','MRI','ACCESS','MIROC')))+
  #scale_color_manual(values=cs)+
  #scale_fill_manual(values=cs)+
  geom_vline(xintercept = 2014, linetype="solid", 
             color = "red", size=1)+
  geom_text(aes(x=year,y=CDD, label = paste("p.value=",round(p.value,4)),colour=timeline), data = cdd_pvalue, size = 4,fontface="bold")+
  geom_text(aes(x=year,y=CDD, label = paste("slope=",round(slope,3),'day/year'),colour=timeline), data = cdd_tau, size = 4,fontface="bold")+
  theme_bw()+
  
  theme(plot.background = element_blank(),
        panel.grid.major =element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(),
        strip.background = element_rect(fill='white'),
        strip.text = element_text(face='bold',size = 16),
        axis.title.y = element_text(face = 'bold',size=16),
        plot.title=element_text(size=16,face='bold'),legend.title = element_text(size = 16,face='bold'),legend.text = element_text(size=16,face='bold'))+
  ylab('CDD(Days)')+
  ggtitle('Cumulative Dry Days (CDD)')+
  coord_cartesian(expand = FALSE, #turn off axis expansion (padding)
                  xlim = c(1979,2100),ylim=c(0,15))
setwd("E:/MW_ClimateChange/Data for frontiers paper/Draft/Edits")
ggsave("cdd_detrend_slope_p.jpeg",width = 12, height=8)
