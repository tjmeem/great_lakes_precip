library(reshape2)
library(ggplot2)
library(tidyverse)
library(plotrix)
library(Kendall)
lakes<- c("Superior","Ontario","Michigan","Huron","Erie")
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/acess")
epd_ac_f<- read.csv("EPD_s6_8.csv",header = FALSE)
epd_ac_avg_f<- data.frame(apply(epd_ac_f[,1:5],1,mean))
colnames(epd_ac_avg_f)<- c("EPD")

setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Superior/Summer")
epd_sup<- read.csv("EPD_s6_8.csv")

setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Ontario/Summer")
epd_ont<- read.csv("EPD_s6_8.csv")

setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Michigan/Summer")
epd_michigan<- read.csv("EPD_s6_8.csv")

setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Huron/Summer")
epd_huron<- read.csv("EPD_s6_8.csv")
setwd("E:/MW_ClimateChange/Data for frontiers paper/NewModels/Basin/Erie/Summer")
epd_erie<- read.csv("EPD_s6_8.csv")

epd_ac_h<- data.frame(epd_sup['access'],epd_ont['access'],epd_michigan['access'],epd_huron['access'],epd_erie['access'])
colnames(epd_ac_h)<- c("Superior","Ontario","Michigan","Huron","Erie")
epd_ac_avg_h<- data.frame(apply(epd_ac_h[,1:5],1,mean))
colnames(epd_ac_avg_h)<- c("EPD")
year<- seq(1979,2100,1)
epd_ac<- rbind(epd_ac_avg_h,epd_ac_avg_f)
epd_ac$year<- year
epd_ac$model<- rep("ACCESS",122)
hist<- data.frame(rep("Historical",36))
fut<- data.frame(rep("SSP5-8.5",86))
colnames(hist)<- colnames(fut)<- c("Type")
Timeline<- rbind(hist,fut)
epd_ac$timeline<- Timeline$Type

setwd("G:/LCS-Filer/ekcarter_r/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/acess")
epd_ac_ssp370<- read.csv("EPD_s6_8.csv",header = TRUE)
colnames(epd_ac_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
epd_ac_avg_ssp370<- data.frame(apply(epd_ac_ssp370[,1:5],1,mean))
colnames(epd_ac_avg_ssp370)<- c("EPD")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
epd_ac_avg_ssp370$year<- year_370
epd_ac_avg_ssp370$timeline<- fut_370
epd_ac_avg_ssp370$model<- rep("ACCESS",86)
epd_ac<- rbind(epd_ac,epd_ac_avg_ssp370)

trend_ac<- data.frame(rep(mean(epd_ac_avg_h$EPD),2))
colnames(trend_ac)<- c("Intercept")
trend_ac$Model<- rep("ACCESS",2)
trend_ac$timeline<- c("SSP3-7.0","SSP5-8.5")
f_yr<- seq(1,86,1)

norm_ac_ssp370<- epd_ac_avg_ssp370$EPD - mean(epd_ac_avg_h$EPD)
norm_ac_ssp585<- epd_ac_avg_f$EPD - mean(epd_ac_avg_h$EPD)
lm_370<- lm(norm_ac_ssp370 ~ f_yr-1)
lm_585<- lm(norm_ac_ssp585~f_yr-1)
trend_ac$slope<- c(lm_370$coefficients,lm_585$coefficients)

#2
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/mpi")
epd_mpi_f<- read.csv("EPD_s6_8.csv",header = TRUE)
colnames(epd_mpi_f)<- c("Superior","Ontario","Michigan","Huron","Erie")
epd_mpi_avg_f<- data.frame(apply(epd_mpi_f[,1:5],1,mean))
colnames(epd_mpi_avg_f)<- c("EPD")
epd_mpi_h<- data.frame(epd_sup['mpi'],epd_ont['mpi'],epd_michigan['mpi'],epd_huron['mpi'],epd_erie['mpi'])
epd_mpi_avg_h<- data.frame(apply(epd_mpi_h[,1:5],1,mean))
colnames(epd_mpi_avg_h)<- c("EPD")
year<- seq(1979,2100,1)
epd_mpi<- rbind(epd_mpi_avg_h,epd_mpi_avg_f)
epd_mpi$year<- year
epd_mpi$model<- rep("MPI",122)
epd_mpi$timeline<- Timeline$Type

setwd("G:/LCS-Filer/ekcarter_r/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/mpi")
epd_mpi_ssp370<- read.csv("EPD_s6_8.csv",header = FALSE)
colnames(epd_mpi_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
epd_mpi_avg_ssp370<- data.frame(apply(epd_mpi_ssp370[,1:5],1,mean))
colnames(epd_mpi_avg_ssp370)<- c("EPD")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
epd_mpi_avg_ssp370$year<- year_370
epd_mpi_avg_ssp370$timeline<- fut_370
epd_mpi_avg_ssp370$model<- rep("MPI",86)
epd_mpi<- rbind(epd_mpi,epd_mpi_avg_ssp370)

trend_mpi<- data.frame(rep(mean(epd_mpi_avg_h$EPD),2))
colnames(trend_mpi)<- c("Intercept")
trend_mpi$Model<- rep("MPI",2)
trend_mpi$timeline<- c("SSP3-7.0","SSP5-8.5")


norm_mpi_ssp370<- epd_mpi_avg_ssp370$EPD - mean(epd_mpi_avg_h$EPD)
norm_mpi_ssp585<- epd_mpi_avg_f$EPD - mean(epd_mpi_avg_h$EPD)
lm_370_mpi<- lm(norm_mpi_ssp370~f_yr-1)
lm_585_mpi<- lm(norm_mpi_ssp585~f_yr-1)
trend_mpi$slope<- c(lm_370_mpi$coefficients,lm_585_mpi$coefficients)

#3
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/mri")
epd_mri_f<- read.csv("EPD_s6_8.csv",header = FALSE)
colnames(epd_mri_f)<- c("Superior","Ontario","Michigan","Huron","Erie")
epd_mri_avg_f<- data.frame(apply(epd_mri_f[,1:5],1,mean))
colnames(epd_mri_avg_f)<- c("EPD")
epd_mri_h<- data.frame(epd_sup['mri'],epd_ont['mri'],epd_michigan['mri'],epd_huron['mri'],epd_erie['mri'])
epd_mri_avg_h<- data.frame(apply(epd_mri_h[,1:5],1,mean))
colnames(epd_mri_avg_h)<- c("EPD")
year<- seq(1979,2100,1)
epd_mri<- rbind(epd_mri_avg_h,epd_mri_avg_f)
epd_mri$year<- year
epd_mri$model<- rep("MRI",122)
epd_mri$timeline<- Timeline$Type

setwd("G:/LCS-Filer/ekcarter_r/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/mri")
epd_mri_ssp370<- read.csv("EPD_s6_8.csv",header = FALSE)
colnames(epd_mri_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
epd_mri_avg_ssp370<- data.frame(apply(epd_mri_ssp370[,1:5],1,mean))
colnames(epd_mri_avg_ssp370)<- c("EPD")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
epd_mri_avg_ssp370$year<- year_370
epd_mri_avg_ssp370$timeline<- fut_370
epd_mri_avg_ssp370$model<- rep("MRI",86)
epd_mri<- rbind(epd_mri,epd_mri_avg_ssp370)

trend_mri<- data.frame(rep(mean(epd_mri_avg_h$EPD),2))
colnames(trend_mri)<-c("Intercept")
trend_mri$Model<- rep("MRI",2)
trend_mri$timeline<- c("SSP3-7.0","SSP5-8.5")


norm_mri_ssp370<- epd_mri_avg_ssp370$EPD - mean(epd_mri_avg_h$EPD)
norm_mri_ssp585<- epd_mri_avg_f$EPD - mean(epd_mri_avg_h$EPD)
lm_370_mri<- lm(norm_mri_ssp370~f_yr-1)
lm_585_mri<- lm(norm_mri_ssp585~f_yr-1)
trend_mri$slope<- c(lm_370_mri$coefficients,lm_585_mri$coefficients)

#4
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ec")
epd_ec_f<- read.csv("EPD_s6_8.csv",header = TRUE)
colnames(epd_ec_f)<- c("Superior","Ontario","Michigan","Huron","Erie")
epd_ec_avg_f<- data.frame(apply(epd_ec_f[,1:5],1,mean))
colnames(epd_ec_avg_f)<- c("EPD")
epd_ec_h<- data.frame(epd_sup['ec_earth'],epd_ont['ec_earth'],epd_michigan['ec_earth'],epd_huron['ec_earth'],epd_erie['ec_earth'])
epd_ec_avg_h<- data.frame(apply(epd_ec_h[,1:5],1,mean))
colnames(epd_ec_avg_h)<- c("EPD")
year<- seq(1979,2100,1)
epd_ec<- rbind(epd_ec_avg_h,epd_ec_avg_f)
epd_ec$year<- year
epd_ec$model<- rep("EC_EARTH",122)
epd_ec$timeline<- Timeline$Type

setwd("G:/LCS-Filer/ekcarter_r/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/ec")
epd_ec_ssp370<- read.csv("EPD_s6_8.csv",header = TRUE)
colnames(epd_ec_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
epd_ec_avg_ssp370<- data.frame(apply(epd_ec_ssp370[,1:5],1,mean))
colnames(epd_ec_avg_ssp370)<- c("EPD")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
epd_ec_avg_ssp370$year<- year_370
epd_ec_avg_ssp370$timeline<- fut_370
epd_ec_avg_ssp370$model<- rep("EC_EARTH",86)
epd_ec<- rbind(epd_ec,epd_ec_avg_ssp370)

trend_ec<- data.frame(rep(mean(epd_ec_avg_h$EPD),2))
colnames(trend_ec)<-c("Intercept")
trend_ec$Model<- rep("EC_EARTH",2)
trend_ec$timeline<- c("SSP3-7.0","SSP5-8.5")


norm_ec_ssp370<- epd_ec_avg_ssp370$EPD - mean(epd_ec_avg_h$EPD)
norm_ec_ssp585<- epd_ec_avg_f$EPD - mean(epd_ec_avg_h$EPD)
lm_370_ec<- lm(norm_ec_ssp370~f_yr-1)
lm_585_ec<- lm(norm_ec_ssp585~f_yr-1)
trend_ec$slope<- c(lm_370_ec$coefficients,lm_585_ec$coefficients)

#5
setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/miroc")
epd_miroc_f<- read.csv("EPD_s6_8.csv",header = TRUE)
colnames(epd_miroc_f)<- c("Superior","Ontario","Michigan","Huron","Erie")
epd_miroc_avg_f<- data.frame(apply(epd_miroc_f[,1:5],1,mean))
colnames(epd_miroc_avg_f)<- c("EPD")
epd_miroc_h<- data.frame(epd_sup['miroc'],epd_ont['miroc'],epd_michigan['miroc'],epd_huron['miroc'],epd_erie['miroc'])
epd_miroc_avg_h<- data.frame(apply(epd_miroc_h[,1:5],1,mean))
colnames(epd_miroc_avg_h)<- c("EPD")
year<- seq(1979,2100,1)
epd_miroc<- rbind(epd_miroc_avg_h,epd_miroc_avg_f)
epd_miroc$year<- year
epd_miroc$model<- rep("MIROC",122)
epd_miroc$timeline<- Timeline$Type

setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/Future/Average/ssp370/miroc")
epd_miroc_ssp370<- read.csv("EPD_s6_8.csv",header = TRUE)
colnames(epd_miroc_ssp370)<- c("Superior","Ontario","Michigan","Huron","Erie")
epd_miroc_avg_ssp370<- data.frame(apply(epd_miroc_ssp370[,1:5],1,mean))
colnames(epd_miroc_avg_ssp370)<- c("EPD")
year_370<- seq(2015,2100,1)
fut_370<- rep("SSP3-7.0",86)
epd_miroc_avg_ssp370$year<- year_370
epd_miroc_avg_ssp370$timeline<- fut_370
epd_miroc_avg_ssp370$model<- rep("MIROC",86)
epd_miroc<- rbind(epd_miroc,epd_miroc_avg_ssp370)

trend_miroc<- data.frame(rep(mean(epd_miroc_avg_h$EPD),2))
colnames(trend_miroc)<-c("Intercept")
trend_miroc$Model<- rep("MIROC",2)
trend_miroc$timeline<- c("SSP3-7.0","SSP5-8.5")
f_yr<- seq(1,86,1)

norm_miroc_ssp370<- epd_miroc_avg_ssp370$EPD - mean(epd_miroc_avg_h$EPD)
norm_miroc_ssp585<- epd_miroc_avg_f$EPD - mean(epd_miroc_avg_h$EPD)
lm_370_miroc<- lm(norm_miroc_ssp370~f_yr-1)
lm_585_miroc<- lm(norm_miroc_ssp585~f_yr-1)
trend_miroc$slope<- c(lm_370_miroc$coefficients,lm_585_miroc$coefficients)

epd_all<- rbind(epd_ac,epd_ec,epd_miroc,epd_mpi,epd_mri)



setwd("E:/MW_ClimateChange/Data for frontiers paper/trace_p/cpc")
lakes<- c("Superior","Ontario","Michigan","Huron","Erie")
epd_cpc<- read.csv("EPD_s6_8.csv",header = TRUE)
epd_cpc_avg<- data.frame(apply(epd_cpc[,1:5],1,mean))
epd_cpc_avg<- data.frame(apply(epd_cpc[,1:5],1,mean))
colnames(epd_cpc_avg)<- c("EPD")
year<- seq(1979,2014,1)
epd_cpc_avg$year<- year
tl<- rep('Observed',36)
epd_cpc_avg$timeline<- tl
epd_cpc_all<- rbind(epd_cpc_avg,epd_cpc_avg,epd_cpc_avg,epd_cpc_avg,epd_cpc_avg)
model<- c(rep('ACCESS',36),rep('EC_EARTH',36),rep('MIROC',36),rep('MPI',36),rep('MRI',36))
epd_cpc_all$model<- model
epd_all<- rbind(epd_all,epd_cpc_all)

#making the dataframe for trends
trend_all<- rbind(trend_ac,trend_ec,trend_miroc,trend_mpi,trend_mri)
trend_all$year<- rep(2014,10)
trend_all$end<- rep(2100,10)
#adding 2014 to the cdd_dataframe (for ggplot)
epd_int<- trend_all%>%
  select(-"slope",-"end")
colnames(epd_int)<- c("EPD","model",'timeline','year')
epd<- rbind(epd_all,epd_int)

trend_final<- trend_all%>%
  select(-'end',-'year')
colnames(trend_final)<- c('intercept','model','timeline','slope')
epd_emission<- epd[epd$timeline%in%c('SSP3-7.0','SSP5-8.5'),]
epd_join<- inner_join(epd_emission,trend_final,by=c('timeline','model'))
epd_join$x<- epd_join$year-2014
epd_join$y<- (epd_join$slope*epd_join$x)+ epd_join$intercept

se<- epd_join%>%
  group_by(model,timeline)%>%
  summarise(std.er= std.error(y))

epd_join_all<- inner_join(epd_join,se,by=c('model','timeline'))
epd_join_all$down<- epd_join_all$y-(1.96*epd_join_all$std.er)
epd_join_all$up<- epd_join_all$y + (1.96*epd_join_all$std.er)
epd_join_all$fy<- epd_join_all$year
epd_ribbon<- epd_join_all%>%select(EPD,model,fy,timeline,up,down)

epd_join_all$norm<-epd_join_all$EPD - epd_join_all$intercept
epd_trend_df<- data.frame(epd_join_all$model,epd_join_all$timeline,epd_join_all$norm)
colnames(epd_trend_df)<- c('model','timeline','norm')
epd_tau<- epd_trend_df %>%
  group_by(model, timeline) %>%
  filter(n() > 1) %>%
  summarize(tau = (MannKendall(norm)$tau))
epd_pvalue<-epd_trend_df %>%
  group_by(model, timeline) %>%
  filter(n() > 1) %>%
  summarize(pvalue = (MannKendall(norm)$sl))
yr<- c(2050,2050)
yr_r<- rep(yr,5)
epd_p<- c(15,1)
epd_p_r<- rep(epd_p,5)
epd_t<-c (17,3)
epd_t_r<- rep(epd_t,5)
epd_pvalue$year<- yr_r
epd_pvalue$EPD<- epd_p_r
epd_tau$year<- yr_r
epd_tau$EPD<- epd_t_r
epd_tau$slope<- trend_all$slope
epd_pvalue$p.value<- c(summary(lm_370)$coefficients[,4],summary(lm_585)$coefficients[,4],summary(lm_370_ec)$coefficients[,4],summary(lm_585_ec)$coefficients[,4],summary(lm_370_miroc)$coefficients[,4],summary(lm_585_miroc)$coefficients[,4],summary(lm_370_mpi)$coefficients[,4],summary(lm_585_mpi)$coefficients[,4],summary(lm_370_mri)$coefficients[,4],summary(lm_370_mri)$coefficients[,4])
#cs<- c('Historical'= 'red','Observed'='black','SSP3-7.0'='purple','SSP5-8.5'='navyblue')

ggplot(data=epd,aes(x=year,y=EPD,fill=timeline,colour=timeline))+
  geom_line(alpha=1)+
  geom_segment(data = trend_final,aes(x=2014,xend=2100,y=intercept,yend=(intercept+slope*86),color=timeline))+
  geom_ribbon(data=epd_ribbon,aes(x=fy,ymin=down,ymax=up,colour=timeline),alpha=0.1)+
  facet_wrap(~factor(model,levels=c('EC_EARTH','MPI','MRI','ACCESS','MIROC')))+
  #scale_color_manual(values = cs)+
  geom_vline(xintercept = 2014, linetype="solid", 
             color = "red", size=1)+
  geom_text(aes(x=year,y=EPD, label = paste("p.value=",round(pvalue,3)),colour=timeline), data = epd_pvalue, size = 4)+
  geom_text(aes(x=year,y=EPD, label = paste("slope =",round(slope,3),'day/year'),colour=timeline), data = epd_tau, size = 4)+
  theme_bw()+
  
  theme(plot.background = element_blank(),
        panel.grid.major =element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(),
        strip.background = element_rect(fill='white'),
        strip.text = element_text(face='bold',size = 16),
        axis.title.y = element_text(face = 'bold',size=16),
        plot.title=element_text(size=16,face='bold'),legend.title = element_text(size = 16,face='bold'),legend.text = element_text(size=16,face='bold'))+
  ylab('EPD(Days)')+
  ggtitle('Extreme Precipitation Days (EPD)')+
  coord_cartesian(expand = FALSE, #turn off axis expansion (padding)
                  xlim = c(1979,2100), ylim = c(0,20))
 
setwd("E:/MW_ClimateChange/Data for frontiers paper/Draft/Edits")
ggsave("epd_detrend_slope_p.jpeg",width = 12, height=8)
